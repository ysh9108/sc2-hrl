from sc2.constants import *
from sc2.static_data import UNIT_TYPES

import numpy

_WHAT_UNITS_USE = [
    UnitTypeId.MINERALFIELD,
    UnitTypeId.MINERALFIELD750,
    UnitTypeId.VESPENEGEYSER,

    UnitTypeId.NEXUS,
    UnitTypeId.PYLON,
    UnitTypeId.ASSIMILATOR,
    UnitTypeId.GATEWAY,
    UnitTypeId.FORGE,
    UnitTypeId.CYBERNETICSCORE,
    UnitTypeId.PHOTONCANNON,
    UnitTypeId.ROBOTICSFACILITY,
    UnitTypeId.STARGATE,
    UnitTypeId.TWILIGHTCOUNCIL,
    UnitTypeId.ROBOTICSBAY,
    UnitTypeId.FLEETBEACON,
    UnitTypeId.TEMPLARARCHIVE,
    UnitTypeId.DARKSHRINE,

    UnitTypeId.PROBE,
    UnitTypeId.ZEALOT,
    UnitTypeId.STALKER,
    UnitTypeId.SENTRY,
    UnitTypeId.ADEPT,
    UnitTypeId.MOTHERSHIPCORE,
    UnitTypeId.OBSERVER,
    UnitTypeId.WARPPRISM,
    UnitTypeId.IMMORTAL,
    UnitTypeId.PHOENIX,
    UnitTypeId.VOIDRAY,
    UnitTypeId.ORACLE,
    UnitTypeId.COLOSSUS,
    UnitTypeId.DISRUPTOR,
    UnitTypeId.CARRIER,
    UnitTypeId.MOTHERSHIP,
    UnitTypeId.TEMPEST,
    UnitTypeId.HIGHTEMPLAR,
    UnitTypeId.ARCHON,
    UnitTypeId.DARKTEMPLAR
]
_WHAT_UNIT_USE_ONEHOT = []

for i, v in enumerate(_WHAT_UNITS_USE):
    _WHAT_UNIT_USE_ONEHOT.append(numpy.zeros(len(_WHAT_UNITS_USE)).astype(numpy.uint8))
    _WHAT_UNIT_USE_ONEHOT[-1][i] = 1

array_size = max(UNIT_TYPES) + 1
UNIT_TYPE_ONEHOT = numpy.zeros((array_size, len(_WHAT_UNIT_USE_ONEHOT))).astype(numpy.uint8)

for i, v in enumerate(_WHAT_UNITS_USE):
    UNIT_TYPE_ONEHOT[v.value] = _WHAT_UNIT_USE_ONEHOT[i]




